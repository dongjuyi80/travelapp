package com.example.android.travel;

import android.content.Context;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

/**
 * {@link CategoryAdapter} is a {@link FragmentPagerAdapter} that can provide the layout for
 * each tab item based on the data source for the text and image.
 */
public class CategoryAdapter extends FragmentPagerAdapter {
    final int PAGE_COUNT = 4;
    private Context mContext;

    //@param context is the context of the app
    //@param fm is the fragment manager that will keep each fragment's state in the adapter across swipes.

    public CategoryAdapter(FragmentManager fm) {
        super(fm);

    }

    @Override
    public int getCount() {
        return PAGE_COUNT;
    }

    @Override
    public Fragment getItem(int position) {
        if (position == 0) {
            return new FoodFragment();
        } else if (position == 1) {
            return new SightsFragment();
        } else if (position == 2) {
            return new BeachFragment();
        } else {
            return new ParksFragment();
        }
    }

    @Override
    public CharSequence getPageTitle(int position) {
        // Generate title based on item position

        if (position == 0) {
            return mContext.getString(R.string.category_food);
        }
        else if (position == 1)
            return mContext.getString(R.string.category_sights);
        else if (position == 2)

        {
            return mContext.getString(R.string.category_beaches);
        } else

        {
            return mContext.getString(R.string.category_parks);
        }

    }

}


