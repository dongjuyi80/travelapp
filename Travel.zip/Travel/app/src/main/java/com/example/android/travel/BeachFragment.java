package com.example.android.travel;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;
import android.support.v4.app.Fragment;

import java.util.ArrayList;

public class BeachFragment extends Fragment {

    @Override
public View onCreateView(LayoutInflater inflater, ViewGroup container,
                         Bundle savedInstanceState) {
    View rootView = inflater.inflate(R.layout.listview, container, false);

    //Create list of sites and images of Barcelona Beaches
    final ArrayList<Word> words = new ArrayList<Word>();
    words.add(new Word(R.string.barcelona_beach,
            R.drawable.barceloneta));


    // Create an {@link WordAdapter}, whose data source is a list of {@link Word}s. The
    // adapter knows how to create list items for each item in the list.
    WordAdapter adapter = new WordAdapter(getActivity(), words);

    // Find the {@link ListView object in the view hierarchy of the {@link Activity}
    // There should be a {@link ListView} with the view ID called list, which is declared in the
    // listview.xml layout file.
    ListView listView = rootView.findViewById(R.id.list);

    // Make the {@link ListView} use the {@link WordAdapter} we created above, so that the
    // {@link ListView} will display information for each {@link Word} in the list.
    listView.setAdapter(adapter);

    return rootView;
}
}

