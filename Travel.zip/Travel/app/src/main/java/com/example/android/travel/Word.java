package com.example.android.travel;

/**
 * {@link Word} represents information about the site.
 * It contains resource IDs for the information about the site and images of the sites.
 */
public class Word {

    /**
     * String resource ID for the information about the site.
     */
    private int mDefaultSiteId;

    /**
     * Drawable resource ID for the image about the site.
     */
    private int mDefaultImageId;


    /**
     * Create a new Word object.
     *
     * @param defaultSiteId is the string resource ID for the information about the site
     * @param defaultImageId   is the drawable resource Id for the image about the site

     */
    public Word(int defaultSiteId, int defaultImageId) {
        mDefaultSiteId = defaultSiteId;
        mDefaultImageId = defaultImageId;

    }

    /**
     * Get the string resource ID for information about the site.
     */
    public int getDefaultSiteId() {
        return mDefaultSiteId;
    }

    /**
     * Return the image resource ID about the site.
     */
    public int getDefaultImageId() {
        return mDefaultImageId;
    }
}
